# CRUD-MySQL-PHP-Flutter
Ejemplo de como crear CRUD en Flutter usando:   MySQL, PHP y JSON

En la carpeta pruebas encontraras los archivos PHP, solo modifica el archivo de conexión con los datos de tu base de datos
y recuerda cambiar las URL de los archivos dart para que coincidan con las rutas donde se encuentren los PHP en tu servidor y la IP de la maquina.

En db_pruebas.sql encontraras el Script para la base de datos.

Pasos para comenzar:

Configura tu entorno:

Instala XAMPP o WAMP para tener un servidor local con PHP y MariaDB.

Asegúrate de tener Flutter instalado en tu máquina.

Prepara la base de datos:

Utiliza el script SQL proporcionado en los repositorios para crear la base de datos y las tablas necesarias.

Configura el backend:

Coloca los archivos PHP en el directorio adecuado de tu servidor local (por ejemplo, en htdocs si usas XAMPP).

Asegúrate de que los archivos PHP estén configurados para conectarse a tu base de datos MariaDB.

Configura el frontend:

Clona el repositorio de Flutter en tu máquina.

Modifica las URLs en los archivos Dart para que apunten a tu servidor local donde se aloja la API PHP.

Ejecuta la aplicación:

Corre el servidor de Flutter utilizando el comando flutter run.

Abre la aplicación en tu emulador o dispositivo físico.
